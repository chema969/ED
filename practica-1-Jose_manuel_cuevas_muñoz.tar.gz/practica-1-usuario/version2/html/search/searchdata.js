var indexSectionsWithContent =
{
  0: "_abcdefgilmoprsuvwy",
  1: "v",
  2: "fmpv",
  3: "abcdeglmopsv",
  4: "_bcfgiopruwy",
  5: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "defines",
  5: "Páginas"
};

