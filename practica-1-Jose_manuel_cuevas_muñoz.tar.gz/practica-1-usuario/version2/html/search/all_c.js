var searchData=
[
  ['place',['PLACE',['../macros_8hpp.html#ad040774f1528e8a40d3c1c525997050f',1,'macros.hpp']]],
  ['principal_2ecpp',['principal.cpp',['../principal_8cpp.html',1,'']]],
  ['productomixto',['productoMixto',['../classed_1_1Vector3D.html#a2063f0cdfdb6a34e4f426a1f247a4459',1,'ed::Vector3D']]],
  ['purple',['PURPLE',['../macros_8hpp.html#a0bb0b009e7a7390473ace4d98bd843c0',1,'macros.hpp']]]
];
